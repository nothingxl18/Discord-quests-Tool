import {
  memo,
  useCallback,
  useDeferredValue,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import type { ReactNode } from "react";
import { invoke } from "@tauri-apps/api/core";
import { listen } from "@tauri-apps/api/event";
import { useVirtualizer } from "@tanstack/react-virtual";
import {
  Activity,
  ChevronLeft,
  ChevronRight,
  Clock,
  Gamepad2,
  Gem,
  Globe,
  History,
  Info,
  Pin,
  PinOff,
  Play,
  Plus,
  RefreshCw,
  Search,
  Sparkles,
  Square,
  Trash2,
  X,
} from "lucide-react";

// ------------------------------------------------------------------- types
type Exec = { name: string; os: string; is_launcher: boolean };
type Game = { id: string; name: string; icon?: string | null; steam_id?: string | null; executables: Exec[] };
type Catalog = { updated_at: number; games: Game[] };
type RunningInfo = {
  key: string;
  app_id: string;
  name: string;
  exe: string;
  path: string;
  pid: number;
  started_at: number;
};
type CustomGame = { id: string; name: string; exe: string };
type Item = {
  id: string;
  name: string;
  custom: boolean;
  execs: Exec[];
  icon: string | null;
  steamId: string | null;
  createdAt: number | null; // derived from the application's snowflake id
  execCount: number; // total registered executables across all platforms
};
type Tab = "home" | "all" | "pinned" | "custom";

const keyOf = (id: string, exe: string) => `${id}::${exe.toLowerCase()}`;
const MAX_RECENT = 20;
const SHELF_SIZE = 30;

function safeParse<T>(s: string, fallback: T): T {
  try {
    return JSON.parse(s) as T;
  } catch {
    return fallback;
  }
}

function fmtTimer(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = String(Math.floor(s / 3600)).padStart(2, "0");
  const m = String(Math.floor((s % 3600) / 60)).padStart(2, "0");
  const sec = String(s % 60).padStart(2, "0");
  return `${h}:${m}:${sec}`;
}

function osLabel(os: string) {
  if (os === "win32") return "Windows";
  if (os === "darwin") return "macOS";
  if (os === "linux") return "Linux";
  return os;
}

/** Discord ids are snowflakes: the top bits hold the creation time. */
function snowflakeTime(id: string): number | null {
  if (!/^\d{15,22}$/.test(id)) return null;
  try {
    return Number((BigInt(id) >> 22n) + 1420070400000n);
  } catch {
    return null;
  }
}

function hashNum(s: string): number {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
  return h;
}

// ------------------------------------------------------------------- thumb
/** Game artwork: Discord app icon first, then Steam art, then a neutral placeholder. */
function Thumb({
  id,
  icon,
  steamId,
  name,
  className = "",
}: {
  id: string;
  icon: string | null;
  steamId: string | null;
  name: string;
  className?: string;
}) {
  const sources = useMemo(() => {
    const out: string[] = [];
    if (icon) out.push(`https://cdn.discordapp.com/app-icons/${id}/${icon}.png?size=256`);
    if (steamId) {
      out.push(`https://cdn.cloudflare.steamstatic.com/steam/apps/${steamId}/library_600x900.jpg`);
      out.push(`https://cdn.cloudflare.steamstatic.com/steam/apps/${steamId}/header.jpg`);
    }
    return out;
  }, [id, icon, steamId]);
  const [idx, setIdx] = useState(0);
  useEffect(() => setIdx(0), [sources]);
  const url = sources[idx];
  const hue = hashNum(id) % 360;

  return (
    <div
      className={`relative h-full w-full overflow-hidden ${className}`}
      style={{ background: `linear-gradient(135deg, hsl(${hue} 45% 26%), hsl(${(hue + 50) % 360} 50% 14%))` }}
    >
      <div className="absolute inset-0 flex items-center justify-center text-white/25">
        <Gamepad2 size={34} />
      </div>
      {url && (
        <img
          key={url}
          src={url}
          alt={name}
          loading="lazy"
          draggable={false}
          onError={() => setIdx((i) => i + 1)}
          className="absolute inset-0 h-full w-full object-cover"
        />
      )}
    </div>
  );
}

// -------------------------------------------------------------- poster tile
type TileProps = {
  item: Item;
  icon: string | null;
  compact?: boolean;
  exe: string;
  running?: RunningInfo;
  pinned: boolean;
  badge?: string;
  onPin: (id: string) => void;
  onStart: (item: Item, exe: string) => void;
  onStop: (key: string) => void;
};

const Tile = memo(function Tile({ item, icon, compact, exe, running, pinned, badge, onPin, onStart, onStop }: TileProps) {
  const active = !!running;
  return (
    <div className={`group shrink-0 ${compact ? "w-[132px]" : "w-[164px]"}`}>
      <div
        className={`relative aspect-square overflow-hidden rounded-2xl border transition-all duration-200 group-hover:-translate-y-0.5 ${
          active
            ? "border-ok shadow-[0_0_20px_rgba(35,165,90,0.45)]"
            : "border-line group-hover:border-primary/70 group-hover:shadow-[0_8px_24px_rgba(88,101,242,0.25)]"
        }`}
      >
        <Thumb id={item.id} icon={icon} steamId={item.steamId} name={item.name} />

        {badge && (
          <span className="absolute left-2 top-2 rounded-md bg-black/65 px-1.5 py-0.5 text-[10px] font-medium text-zinc-100 backdrop-blur">
            {badge}
          </span>
        )}
        {active && (
          <span className="absolute left-2 top-2 flex items-center gap-1 rounded-md bg-ok px-1.5 py-0.5 text-[10px] font-bold text-white">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" /> LIVE
          </span>
        )}

        <button
          onClick={() => onPin(item.id)}
          title={pinned ? "Unpin" : "Pin"}
          className={`absolute right-2 top-2 rounded-lg bg-black/60 p-1.5 backdrop-blur transition-opacity hover:bg-black/80 ${
            pinned ? "text-primary opacity-100" : "text-zinc-200 opacity-0 group-hover:opacity-100"
          }`}
        >
          {pinned ? <PinOff size={14} /> : <Pin size={14} />}
        </button>

        <div
          className={`absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent p-2 pt-8 transition-opacity ${
            active ? "opacity-100" : "opacity-0 group-hover:opacity-100"
          }`}
        >
          {active ? (
            <button
              onClick={() => onStop(running!.key)}
              className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-danger py-1.5 text-xs font-semibold text-white hover:brightness-110"
            >
              <Square size={12} fill="currentColor" /> Stop
            </button>
          ) : (
            <button
              onClick={() => onStart(item, exe)}
              className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-primary py-1.5 text-xs font-semibold text-white hover:brightness-110"
            >
              <Play size={12} fill="currentColor" /> Start
            </button>
          )}
        </div>
      </div>
      <div className="mt-2 px-0.5">
        <div className="truncate text-[13px] font-semibold text-white" title={item.name}>
          {item.name}
        </div>
        <div className="truncate font-mono text-[10px] text-zinc-500" title={exe}>
          {exe}
        </div>
      </div>
    </div>
  );
});

// -------------------------------------------------------------------- shelf
function Shelf({
  title,
  subtitle,
  icon,
  empty,
  children,
}: {
  title: string;
  subtitle: string;
  icon: ReactNode;
  empty?: string;
  children?: ReactNode;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: number) =>
    ref.current?.scrollBy({ left: dir * ref.current.clientWidth * 0.8, behavior: "smooth" });

  return (
    <section className="mb-8">
      <div className="mb-3 flex items-end justify-between">
        <div>
          <h2 className="flex items-center gap-2 text-base font-bold text-white">
            <span className="text-primary">{icon}</span> {title}
          </h2>
          <p className="mt-0.5 text-[11px] text-zinc-500">{subtitle}</p>
        </div>
        {!empty && (
          <div className="flex gap-1.5">
            <button
              onClick={() => scroll(-1)}
              className="rounded-lg border border-line bg-surface p-1.5 text-zinc-400 hover:border-primary hover:text-white"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={() => scroll(1)}
              className="rounded-lg border border-line bg-surface p-1.5 text-zinc-400 hover:border-primary hover:text-white"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        )}
      </div>
      {empty ? (
        <div className="rounded-xl border border-dashed border-line bg-surface/40 px-4 py-6 text-center text-xs text-zinc-500">
          {empty}
        </div>
      ) : (
        <div ref={ref} className="no-scrollbar -mx-1 flex gap-3.5 overflow-x-auto px-1 pb-3 pt-1">
          {children}
        </div>
      )}
    </section>
  );
}

// ------------------------------------------------------- library grid card
const MIN_CARD = 340;
const GAP = 12;
const ROW_HEIGHT = 140;

type CardProps = {
  item: Item;
  icon: string | null;
  exe: string;
  platform: string;
  running?: RunningInfo;
  pinned: boolean;
  onSelect: (id: string, exe: string) => void;
  onPin: (id: string) => void;
  onStart: (item: Item, exe: string) => void;
  onStop: (key: string) => void;
  onDelete: (id: string) => void;
};

const GameCard = memo(function GameCard(p: CardProps) {
  const { item, running, pinned } = p;
  const cur = item.execs.find((e) => e.name === p.exe) ?? item.execs[0];
  const active = !!running;
  const matches = cur.os === p.platform || item.custom;

  return (
    <div
      className={`flex h-[128px] gap-3 rounded-2xl border bg-surface/90 p-3 transition-colors ${
        active ? "border-ok/70 shadow-[0_0_16px_rgba(35,165,90,0.25)]" : "border-line hover:border-primary/60"
      }`}
    >
      <div className="h-[100px] w-[100px] shrink-0 overflow-hidden rounded-xl border border-line">
        <Thumb id={item.id} icon={p.icon} steamId={item.steamId} name={item.name} />
      </div>
      <div className="flex min-w-0 flex-1 flex-col justify-between">
        <div className="flex items-start justify-between gap-1">
          <div className="min-w-0">
            <h3 className="truncate text-sm font-semibold text-white" title={item.name}>
              {item.name}
            </h3>
            <div className="mt-1 flex items-center gap-1.5">
              <span
                className={`rounded px-1.5 py-0.5 text-[10px] font-medium ${
                  matches ? "bg-ok/15 text-ok" : "bg-amber-500/15 text-amber-400"
                }`}
              >
                {item.custom ? "Custom" : osLabel(cur.os)}
              </span>
              {cur.is_launcher && (
                <span className="rounded bg-primary/15 px-1.5 py-0.5 text-[10px] font-medium text-primary">
                  Launcher
                </span>
              )}
            </div>
          </div>
          <div className="flex shrink-0">
            {item.custom && (
              <button
                onClick={() => p.onDelete(item.id)}
                className="rounded-md p-1 text-zinc-500 hover:bg-danger/10 hover:text-danger"
                title="Delete custom game"
              >
                <Trash2 size={14} />
              </button>
            )}
            <button
              onClick={() => p.onPin(item.id)}
              className={`rounded-md p-1 hover:bg-white/5 ${pinned ? "text-primary" : "text-zinc-500 hover:text-zinc-200"}`}
              title={pinned ? "Unpin" : "Pin"}
            >
              {pinned ? <PinOff size={14} /> : <Pin size={14} />}
            </button>
          </div>
        </div>

        {item.execs.length > 1 ? (
          <select
            value={cur.name}
            disabled={active}
            onChange={(e) => p.onSelect(item.id, e.target.value)}
            className="w-full truncate rounded-md border border-line bg-canvas px-2 py-1 font-mono text-[11px] text-zinc-300 outline-none focus:border-primary disabled:opacity-60"
          >
            {item.execs.map((e) => (
              <option key={e.name + e.os} value={e.name}>
                {e.name} ({osLabel(e.os)})
              </option>
            ))}
          </select>
        ) : (
          <div
            className="truncate rounded-md border border-line bg-canvas px-2 py-1 font-mono text-[11px] text-zinc-400"
            title={cur.name}
          >
            {cur.name}
          </div>
        )}

        {active ? (
          <button
            onClick={() => p.onStop(running!.key)}
            className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-danger py-1.5 text-xs font-semibold text-white hover:brightness-110"
          >
            <Square size={12} fill="currentColor" /> Stop
          </button>
        ) : (
          <button
            onClick={() => p.onStart(item, cur.name)}
            className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-primary py-1.5 text-xs font-semibold text-white hover:brightness-110"
          >
            <Play size={12} fill="currentColor" /> Start
          </button>
        )}
      </div>
    </div>
  );
});

type LibraryProps = {
  items: Item[];
  iconMap: Record<string, string>;
  onNeedIcons: (ids: string[]) => void;
  platform: string;
  execSel: Record<string, string>;
  runningByKey: Map<string, RunningInfo>;
  pinned: Set<string>;
  onSelect: (id: string, exe: string) => void;
  onPin: (id: string) => void;
  onStart: (item: Item, exe: string) => void;
  onStop: (key: string) => void;
  onDelete: (id: string) => void;
};

function Library(p: LibraryProps) {
  const parentRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(1000);

  useEffect(() => {
    const el = parentRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setWidth(el.clientWidth));
    ro.observe(el);
    setWidth(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  const cols = Math.max(1, Math.floor((width - 48 + GAP) / (MIN_CARD + GAP)));
  const rowCount = Math.ceil(p.items.length / cols);

  const virt = useVirtualizer({
    count: rowCount,
    getScrollElement: () => parentRef.current,
    estimateSize: () => ROW_HEIGHT,
    overscan: 6,
  });

  const vItems = virt.getVirtualItems();
  const firstRow = vItems.length ? vItems[0].index : 0;
  const lastRow = vItems.length ? vItems[vItems.length - 1].index : 0;
  const { items: libItems, onNeedIcons } = p;
  useEffect(() => {
    const ids = libItems
      .slice(firstRow * cols, (lastRow + 1) * cols)
      .filter((i) => !i.icon)
      .map((i) => i.id);
    if (ids.length) onNeedIcons(ids);
  }, [firstRow, lastRow, cols, libItems, onNeedIcons]);

  return (
    <div ref={parentRef} className="h-full overflow-y-auto px-6 pb-8">
      <div style={{ height: virt.getTotalSize(), position: "relative", width: "100%" }}>
        {virt.getVirtualItems().map((vr) => {
          const slice = p.items.slice(vr.index * cols, vr.index * cols + cols);
          return (
            <div
              key={vr.key}
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: vr.size,
                transform: `translateY(${vr.start}px)`,
                display: "grid",
                gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
                gap: GAP,
                paddingBottom: GAP,
              }}
            >
              {slice.map((item) => {
                const exe = p.execSel[item.id] ?? item.execs[0].name;
                return (
                  <GameCard
                    key={item.id}
                    item={item}
                    icon={item.icon ?? p.iconMap[item.id] ?? null}
                    exe={exe}
                    platform={p.platform}
                    running={p.runningByKey.get(keyOf(item.id, exe))}
                    pinned={p.pinned.has(item.id)}
                    onSelect={p.onSelect}
                    onPin={p.onPin}
                    onStart={p.onStart}
                    onStop={p.onStop}
                    onDelete={p.onDelete}
                  />
                );
              })}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// --------------------------------------------------------------------- app
export default function App() {
  const [platform, setPlatform] = useState("win32");
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [syncing, setSyncing] = useState(false);
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState<Tab>("home");
  const [allPlatforms, setAllPlatforms] = useState(false);
  const [pinned, setPinned] = useState<Set<string>>(new Set());
  const [recent, setRecent] = useState<string[]>([]);
  const [custom, setCustom] = useState<CustomGame[]>([]);
  const [running, setRunning] = useState<RunningInfo[]>([]);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [bannerOpen, setBannerOpen] = useState(true);
  const [execSel, setExecSel] = useState<Record<string, string>>({});
  const [iconMap, setIconMap] = useState<Record<string, string>>({});
  const iconAsked = useRef<Set<string>>(new Set());
  const [now, setNow] = useState(Date.now());
  const [notice, setNotice] = useState<{ kind: "error" | "info"; text: string } | null>(null);

  const flash = useCallback((kind: "error" | "info", text: string) => {
    setNotice({ kind, text });
    window.setTimeout(() => setNotice(null), 5000);
  }, []);

  const syncCatalog = useCallback(
    async (silent: boolean) => {
      setSyncing(true);
      try {
        const c = await invoke<Catalog>("sync_catalog");
        setCatalog(c);
        if (!silent) flash("info", `Catalog synced: ${c.games.length.toLocaleString()} games`);
      } catch (e) {
        flash("error", `Sync failed: ${String(e)}. Using cached catalog if available.`);
      } finally {
        setSyncing(false);
      }
    },
    [flash]
  );

  useEffect(() => {
    let unlisten: (() => void) | undefined;
    let cancelled = false;
    (async () => {
      try {
        setPlatform(await invoke<string>("get_platform"));
        setPinned(new Set(safeParse<string[]>(await invoke<string>("read_store", { name: "pinned.json" }), [])));
        setRecent(safeParse<string[]>(await invoke<string>("read_store", { name: "recent.json" }), []));
        setCustom(safeParse<CustomGame[]>(await invoke<string>("read_store", { name: "custom_games.json" }), []));
        setRunning(await invoke<RunningInfo[]>("list_running"));
        const cached = await invoke<Catalog | null>("load_catalog");
        if (cached) setCatalog(cached);
        const un = await listen<RunningInfo[]>("running-changed", (e) => setRunning(e.payload));
        if (cancelled) un();
        else unlisten = un;
      } catch (e) {
        flash("error", String(e));
      }
      if (!cancelled) syncCatalog(true);
    })();
    return () => {
      cancelled = true;
      unlisten?.();
    };
  }, [flash, syncCatalog]);

  useEffect(() => {
    if (running.length === 0) return;
    const t = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(t);
  }, [running.length]);

  const items = useMemo(() => {
    const out: Item[] = [];
    for (const g of catalog?.games ?? []) {
      const execs = allPlatforms ? g.executables : g.executables.filter((e) => e.os === platform);
      if (execs.length === 0) continue;
      out.push({
        id: g.id,
        name: g.name,
        custom: false,
        icon: g.icon ?? null,
        steamId: g.steam_id ?? null,
        createdAt: snowflakeTime(g.id),
        execCount: g.executables.length,
        execs: [...execs].sort((a, b) => Number(a.is_launcher) - Number(b.is_launcher)),
      });
    }
    for (const c of custom) {
      out.push({
        id: c.id,
        name: c.name,
        custom: true,
        icon: null,
        steamId: null,
        createdAt: null,
        execCount: 1,
        execs: [{ name: c.exe, os: platform, is_launcher: false }],
      });
    }
    return out;
  }, [catalog, custom, allPlatforms, platform]);

  const itemById = useMemo(() => new Map(items.map((i) => [i.id, i])), [items]);

  // ---- Home shelves
  const shelves = useMemo(() => {
    const prefer = (list: Item[]) => {
      const withIcons = list.filter((i) => i.icon || i.steamId);
      return withIcons.length >= 8 ? withIcons : list;
    };
    const catalogItems = items.filter((i) => !i.custom);

    const pinnedItems = [...pinned].map((id) => itemById.get(id)).filter((i): i is Item => !!i);
    const recentItems = recent.map((id) => itemById.get(id)).filter((i): i is Item => !!i);

    const newItems = prefer(catalogItems.filter((i) => i.createdAt))
      .sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0))
      .slice(0, SHELF_SIZE);

    // Discord's catalog has no player counts. Heuristic: big titles register many
    // executables (launchers, per-OS builds); niche ones register just one.
    const leastItems = prefer(catalogItems)
      .slice()
      .sort((a, b) => a.execCount - b.execCount || hashNum(a.id) - hashNum(b.id))
      .slice(0, SHELF_SIZE);

    return { pinnedItems, recentItems, newItems, leastItems };
  }, [items, itemById, pinned, recent]);

  const q = useDeferredValue(search).trim().toLowerCase();
  const showHome = tab === "home" && !q;

  const visible = useMemo(
    () =>
      items.filter((it) => {
        if (tab === "pinned" && !pinned.has(it.id)) return false;
        if (tab === "custom" && !it.custom) return false;
        if (!q) return true;
        return it.name.toLowerCase().includes(q) || it.execs.some((e) => e.name.toLowerCase().includes(q));
      }),
    [items, tab, pinned, q]
  );

  const requestIcons = useCallback((ids: string[]) => {
    const fresh = ids.filter((id) => /^\d+$/.test(id) && !iconAsked.current.has(id));
    if (fresh.length === 0) return;
    fresh.forEach((id) => iconAsked.current.add(id));
    for (let i = 0; i < fresh.length; i += 40) {
      const batch = fresh.slice(i, i + 40);
      invoke<Record<string, string>>("resolve_icons", { ids: batch })
        .then((m) => {
          if (Object.keys(m).length > 0) setIconMap((prev) => ({ ...prev, ...m }));
        })
        .catch(() => batch.forEach((id) => iconAsked.current.delete(id)));
    }
  }, []);

  useEffect(() => {
    if (!showHome) return;
    const ids = [...shelves.pinnedItems, ...shelves.recentItems, ...shelves.newItems, ...shelves.leastItems]
      .filter((i) => !i.icon)
      .map((i) => i.id);
    requestIcons(ids);
  }, [showHome, shelves, requestIcons]);

  const runningByKey = useMemo(() => new Map(running.map((r) => [r.key, r])), [running]);

  const onSelect = useCallback((id: string, exe: string) => setExecSel((s) => ({ ...s, [id]: exe })), []);

  const onPin = useCallback(
    (id: string) => {
      setPinned((prev) => {
        const next = new Set(prev);
        if (next.has(id)) next.delete(id);
        else next.add(id);
        invoke("write_store", { name: "pinned.json", data: JSON.stringify([...next]) }).catch((e) =>
          flash("error", String(e))
        );
        return next;
      });
    },
    [flash]
  );

  const onStart = useCallback(
    async (item: Item, exe: string) => {
      try {
        await invoke("start_game", { appId: item.id, name: item.name, exe });
        setRecent((prev) => {
          const next = [item.id, ...prev.filter((x) => x !== item.id)].slice(0, MAX_RECENT);
          invoke("write_store", { name: "recent.json", data: JSON.stringify(next) }).catch(() => {});
          return next;
        });
      } catch (e) {
        flash("error", `Could not start ${item.name}: ${String(e)}`);
      }
    },
    [flash]
  );

  const onStop = useCallback(
    async (key: string) => {
      try {
        await invoke("stop_game", { key });
      } catch (e) {
        flash("error", String(e));
      }
    },
    [flash]
  );

  const stopAll = async () => {
    try {
      await invoke("stop_all");
    } catch (e) {
      flash("error", String(e));
    }
  };

  const onDelete = useCallback(
    (id: string) => {
      setCustom((prev) => {
        const next = prev.filter((c) => c.id !== id);
        invoke("write_store", { name: "custom_games.json", data: JSON.stringify(next) }).catch((e) =>
          flash("error", String(e))
        );
        return next;
      });
    },
    [flash]
  );

  const renderTile = (item: Item, badge?: string, compact?: boolean) => {
    const exe = execSel[item.id] ?? item.execs[0].name;
    return (
      <Tile
        key={item.id}
        item={item}
        icon={item.icon ?? iconMap[item.id] ?? null}
        compact={compact}
        exe={exe}
        running={runningByKey.get(keyOf(item.id, exe))}
        pinned={pinned.has(item.id)}
        badge={badge}
        onPin={onPin}
        onStart={onStart}
        onStop={onStop}
      />
    );
  };

  const addedLabel = (i: Item) =>
    i.createdAt ? new Date(i.createdAt).toLocaleDateString(undefined, { month: "short", year: "numeric" }) : undefined;

  const tabs: { id: Tab; label: string }[] = [
    { id: "home", label: "Home" },
    { id: "all", label: "All Games" },
    { id: "pinned", label: "Pinned" },
    { id: "custom", label: "Custom" },
  ];

  return (
    <div className="flex h-full flex-col text-zinc-200">
      {/* Header */}
      <header className="border-b border-line bg-canvas/80 px-6 pb-3 pt-3 backdrop-blur">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary shadow-lg shadow-primary/30">
              <Gamepad2 size={20} className="text-white" />
            </div>
            <div className="leading-tight">
              <div className="text-sm font-bold text-white">GameSpoof Studio</div>
              <div className="text-[10px] text-zinc-500">Local dummy game launcher</div>
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-xl">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by game title or executable name…"
              className="w-full rounded-xl border border-line bg-surface py-2 pl-9 pr-8 text-sm text-white outline-none placeholder:text-zinc-500 focus:border-primary"
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"
              >
                <X size={14} />
              </button>
            )}
          </div>

          <button
            onClick={() => setDrawerOpen(true)}
            className={`flex items-center gap-2 rounded-xl border px-3 py-2 text-sm font-medium transition-colors ${
              running.length
                ? "glow border-ok/60 bg-ok/10 text-ok"
                : "border-line bg-surface text-zinc-400 hover:text-white"
            }`}
            title="Running games"
          >
            <Activity size={16} />
            {running.length > 0 ? `${running.length} Active` : "Running"}
          </button>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-3">
          <div className="flex rounded-xl border border-line bg-surface p-0.5">
            {tabs.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`rounded-lg px-3.5 py-1 text-xs font-medium transition-colors ${
                  tab === t.id ? "bg-primary text-white" : "text-zinc-400 hover:text-white"
                }`}
              >
                {t.label}
                {t.id === "pinned" && pinned.size > 0 && <span className="ml-1.5 opacity-70">{pinned.size}</span>}
              </button>
            ))}
          </div>

          <label className="flex cursor-pointer items-center gap-2 text-xs text-zinc-400">
            <button
              role="switch"
              aria-checked={allPlatforms}
              onClick={() => setAllPlatforms((v) => !v)}
              className={`relative h-5 w-9 rounded-full transition-colors ${allPlatforms ? "bg-primary" : "bg-line"}`}
            >
              <span
                className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${
                  allPlatforms ? "left-[18px]" : "left-0.5"
                }`}
              />
            </button>
            <Globe size={13} /> All platforms
            <span className="text-zinc-600">(current: {osLabel(platform)})</span>
          </label>

          <div className="ml-auto flex items-center gap-3">
            <span className="flex items-center gap-1.5 text-[11px] text-zinc-500">
              <Clock size={12} />
              {catalog
                ? `${catalog.games.length.toLocaleString()} games · updated ${new Date(catalog.updated_at).toLocaleString()}`
                : "No catalog yet"}
            </span>
            <button
              onClick={() => syncCatalog(false)}
              disabled={syncing}
              className="flex items-center gap-1.5 rounded-xl border border-line bg-surface px-3 py-1.5 text-xs font-medium text-zinc-300 hover:border-primary hover:text-white disabled:opacity-60"
            >
              <RefreshCw size={13} className={syncing ? "animate-spin" : ""} />
              Sync Catalog
            </button>
            <button
              onClick={() => setAddOpen(true)}
              className="flex items-center gap-1.5 rounded-xl bg-primary px-3 py-1.5 text-xs font-semibold text-white hover:brightness-110"
            >
              <Plus size={14} /> Custom Game
            </button>
          </div>
        </div>
      </header>

      {bannerOpen && (
        <div className="mx-6 mt-3 flex items-start gap-2 rounded-xl border border-primary/30 bg-primary/10 px-3 py-2 text-xs text-zinc-300">
          <Info size={14} className="mt-0.5 shrink-0 text-primary" />
          <span className="flex-1">
            If Discord doesn't detect a game right away, open <b>Discord › Settings › Registered Games</b> and add the
            running process once. This is especially useful on macOS for titles that only list Windows executables.
          </span>
          <button onClick={() => setBannerOpen(false)} className="text-zinc-500 hover:text-white">
            <X size={14} />
          </button>
        </div>
      )}

      {/* Main */}
      <main className="mt-4 min-h-0 flex-1">
        {showHome ? (
          <div className="h-full overflow-y-auto px-6 pb-10">
            <Shelf
              title="Pinned"
              subtitle="Your favorites, one click away"
              icon={<Pin size={16} />}
              empty={shelves.pinnedItems.length === 0 ? "Nothing pinned yet. Hover any game and click the pin icon." : undefined}
            >
              {shelves.pinnedItems.map((i) => renderTile(i))}
            </Shelf>

            <Shelf
              title="Recently Opened"
              subtitle="Games you launched lately"
              icon={<History size={16} />}
              empty={shelves.recentItems.length === 0 ? "Games you start will show up here." : undefined}
            >
              {shelves.recentItems.map((i) => renderTile(i, undefined, true))}
            </Shelf>

            <Shelf
              title="New Releases"
              subtitle="Newest additions to Discord's detectable catalog"
              icon={<Sparkles size={16} />}
              empty={shelves.newItems.length === 0 ? (syncing ? "Loading catalog…" : "No games available yet.") : undefined}
            >
              {shelves.newItems.map((i) => renderTile(i, addedLabel(i)))}
            </Shelf>

            <Shelf
              title="Least Popular"
              subtitle="Hidden gems — estimated from catalog data (Discord publishes no player counts)"
              icon={<Gem size={16} />}
              empty={shelves.leastItems.length === 0 ? (syncing ? "Loading catalog…" : "No games available yet.") : undefined}
            >
              {shelves.leastItems.map((i) => renderTile(i))}
            </Shelf>
          </div>
        ) : visible.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-2 text-center text-sm text-zinc-500">
            <Gamepad2 size={36} className="text-zinc-700" />
            {syncing && !catalog ? (
              <p>Downloading the detectable games catalog…</p>
            ) : tab === "pinned" ? (
              <p>No pinned games yet. Click the pin icon on any game.</p>
            ) : tab === "custom" ? (
              <p>No custom games yet. Use “Custom Game” to add an executable name.</p>
            ) : (
              <p>
                No games match.
                {!allPlatforms && " Try enabling “All platforms” to include executables listed for other systems."}
              </p>
            )}
          </div>
        ) : (
          <div className="flex h-full flex-col">
            <div className="px-6 pb-3 text-xs text-zinc-500">
              {q ? `${visible.length.toLocaleString()} results for “${search.trim()}”` : `${visible.length.toLocaleString()} games`}
            </div>
            <div className="min-h-0 flex-1">
              <Library
                items={visible}
                iconMap={iconMap}
                onNeedIcons={requestIcons}
                platform={platform}
                execSel={execSel}
                runningByKey={runningByKey}
                pinned={pinned}
                onSelect={onSelect}
                onPin={onPin}
                onStart={onStart}
                onStop={onStop}
                onDelete={onDelete}
              />
            </div>
          </div>
        )}
      </main>

      {/* Running drawer */}
      <div
        className={`fixed inset-0 z-40 bg-black/50 transition-opacity ${
          drawerOpen ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        onClick={() => setDrawerOpen(false)}
      />
      <aside
        className={`fixed right-0 top-0 z-50 flex h-full w-[420px] max-w-full flex-col border-l border-line bg-surface shadow-2xl transition-transform duration-200 ${
          drawerOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between border-b border-line px-4 py-3">
          <div className="flex items-center gap-2 text-sm font-semibold text-white">
            <Activity size={16} className="text-ok" /> Running Games
            <span className="rounded-full bg-ok/15 px-2 py-0.5 text-[11px] text-ok">{running.length}</span>
          </div>
          <div className="flex items-center gap-2">
            {running.length > 0 && (
              <button
                onClick={stopAll}
                className="rounded-lg bg-danger px-2.5 py-1 text-xs font-semibold text-white hover:brightness-110"
              >
                Stop All
              </button>
            )}
            <button onClick={() => setDrawerOpen(false)} className="text-zinc-400 hover:text-white">
              <X size={18} />
            </button>
          </div>
        </div>
        <div className="flex-1 space-y-2.5 overflow-y-auto p-4">
          {running.length === 0 && <p className="pt-10 text-center text-sm text-zinc-500">Nothing is running.</p>}
          {[...running]
            .sort((a, b) => a.started_at - b.started_at)
            .map((r) => {
              const it = itemById.get(r.app_id);
              return (
                <div key={r.key} className="rounded-xl border border-line bg-canvas p-3">
                  <div className="flex items-center gap-3">
                    <div className="h-11 w-11 shrink-0 overflow-hidden rounded-lg border border-line">
                      <Thumb id={r.app_id} icon={it?.icon ?? iconMap[r.app_id] ?? null} steamId={it?.steamId ?? null} name={r.name} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="truncate text-sm font-semibold text-white">{r.name}</span>
                        <span className="font-mono text-sm tabular-nums text-ok">{fmtTimer(now - r.started_at)}</span>
                      </div>
                      <div className="text-[11px] text-zinc-500">PID {r.pid}</div>
                    </div>
                  </div>
                  <div className="mt-2 break-all rounded-md border border-line bg-surface px-2 py-1 font-mono text-[10.5px] text-zinc-400">
                    {r.path}
                  </div>
                  <div className="mt-2 flex justify-end">
                    <button
                      onClick={() => onStop(r.key)}
                      className="flex items-center gap-1.5 rounded-lg bg-danger px-2.5 py-1 text-xs font-semibold text-white hover:brightness-110"
                    >
                      <Square size={11} fill="currentColor" /> Stop
                    </button>
                  </div>
                </div>
              );
            })}
        </div>
      </aside>

      {addOpen && (
        <AddCustomModal
          onClose={() => setAddOpen(false)}
          onAdd={(name, exe) => {
            const next = [...custom, { id: `custom-${Date.now()}`, name, exe }];
            setCustom(next);
            invoke("write_store", { name: "custom_games.json", data: JSON.stringify(next) }).catch((e) =>
              flash("error", String(e))
            );
            setAddOpen(false);
            setTab("custom");
          }}
        />
      )}

      {notice && (
        <div
          className={`fixed bottom-4 left-1/2 z-[60] -translate-x-1/2 rounded-lg border px-4 py-2 text-xs shadow-xl ${
            notice.kind === "error"
              ? "border-danger/50 bg-danger/15 text-red-200"
              : "border-ok/50 bg-ok/15 text-emerald-200"
          }`}
        >
          {notice.text}
        </div>
      )}
    </div>
  );
}

// -------------------------------------------------------------------- modal
function AddCustomModal({ onClose, onAdd }: { onClose: () => void; onAdd: (name: string, exe: string) => void }) {
  const [name, setName] = useState("");
  const [exe, setExe] = useState("");
  const valid = name.trim().length > 0 && exe.trim().length > 0;

  return (
    <div className="fixed inset-0 z-[55] flex items-center justify-center bg-black/60" onClick={onClose}>
      <div
        className="w-[440px] rounded-2xl border border-line bg-surface p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-white">Add Custom Game</h2>
          <button onClick={onClose} className="text-zinc-400 hover:text-white">
            <X size={16} />
          </button>
        </div>
        <label className="mb-1 block text-xs text-zinc-400">Display name</label>
        <input
          autoFocus
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="My Game"
          className="mb-3 w-full rounded-lg border border-line bg-canvas px-3 py-2 text-sm text-white outline-none focus:border-primary"
        />
        <label className="mb-1 block text-xs text-zinc-400">Executable name or relative path</label>
        <input
          value={exe}
          onChange={(e) => setExe(e.target.value)}
          placeholder="Binaries/Win64/Game.exe"
          className="w-full rounded-lg border border-line bg-canvas px-3 py-2 font-mono text-sm text-white outline-none focus:border-primary"
        />
        <p className="mt-2 text-[11px] text-zinc-500">
          Use the same folder layout Discord expects, e.g. <span className="font-mono">Game.app/Contents/MacOS/Game</span>{" "}
          on macOS.
        </p>
        <div className="mt-4 flex justify-end gap-2">
          <button onClick={onClose} className="rounded-lg px-3 py-1.5 text-xs text-zinc-400 hover:text-white">
            Cancel
          </button>
          <button
            disabled={!valid}
            onClick={() => onAdd(name.trim(), exe.trim())}
            className="rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-white hover:brightness-110 disabled:opacity-40"
          >
            Add Game
          </button>
        </div>
      </div>
    </div>
  );
}
