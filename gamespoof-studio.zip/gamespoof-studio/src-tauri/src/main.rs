// Prevents an extra console window on Windows in release builds.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    // Idle-stub mode: when this binary is copied to a "game" path and launched
    // with this flag, it does nothing and uses 0% CPU. No window, no webview.
    if std::env::args().any(|a| a == gamespoof_studio_lib::IDLE_FLAG) {
        loop {
            std::thread::sleep(std::time::Duration::from_secs(3600));
        }
    }
    gamespoof_studio_lib::run()
}
