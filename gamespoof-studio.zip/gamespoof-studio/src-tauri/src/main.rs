// Prevents an extra console window on Windows in release builds.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    // Idle-stub mode: this binary was copied to a "game" path and launched with
    // the flag (+ a window title). It shows a tiny window (Windows) and idles at 0% CPU.
    let args: Vec<String> = std::env::args().collect();
    if let Some(i) = args.iter().position(|a| a == gamespoof_studio_lib::IDLE_FLAG) {
        let title = args.get(i + 1).cloned().unwrap_or_else(|| "GameSpoof dummy".into());
        gamespoof_studio_lib::run_idle(&title);
        return;
    }
    gamespoof_studio_lib::run()
}
