use serde::{Deserialize, Serialize};
use std::{
    collections::HashMap,
    fs,
    path::{Path, PathBuf},
    process::{Child, Command, Stdio},
    sync::{Mutex, MutexGuard},
    time::{Duration, SystemTime, UNIX_EPOCH},
};
use tauri::{AppHandle, Emitter, Manager, RunEvent, State};

/// Argument that turns the app binary into a zero-CPU idle stub (see main.rs).
pub const IDLE_FLAG: &str = "--gamespoof-idle";
const DETECTABLE_URL: &str = "https://discord.com/api/v9/applications/detectable";
const STORE_NAMES: [&str; 3] = ["pinned.json", "custom_games.json", "recent.json"];

// ---------------------------------------------------------------- data types

#[derive(Serialize, Deserialize, Clone)]
struct ExecEntry {
    name: String,
    os: String,
    is_launcher: bool,
}

#[derive(Serialize, Deserialize, Clone)]
struct Game {
    id: String,
    name: String,
    #[serde(default)]
    icon: Option<String>,
    #[serde(default)]
    steam_id: Option<String>,
    executables: Vec<ExecEntry>,
}

#[derive(Serialize, Deserialize, Clone)]
struct Catalog {
    updated_at: u64,
    games: Vec<Game>,
}

struct Running {
    key: String,
    app_id: String,
    name: String,
    exe: String,
    path: PathBuf,
    root: PathBuf,
    pid: u32,
    started_at: u64,
    child: Child,
}

#[derive(Serialize, Clone)]
struct RunningInfo {
    key: String,
    app_id: String,
    name: String,
    exe: String,
    path: String,
    pid: u32,
    started_at: u64,
}

impl Running {
    fn info(&self) -> RunningInfo {
        RunningInfo {
            key: self.key.clone(),
            app_id: self.app_id.clone(),
            name: self.name.clone(),
            exe: self.exe.clone(),
            path: self.path.to_string_lossy().to_string(),
            pid: self.pid,
            started_at: self.started_at,
        }
    }
}

#[derive(Default)]
struct AppState {
    running: Mutex<HashMap<String, Running>>,
}

fn lock(state: &AppState) -> MutexGuard<'_, HashMap<String, Running>> {
    state.running.lock().unwrap_or_else(|e| e.into_inner())
}


/// Runs inside the dummy process. On Windows it opens a small real window and
/// blocks in the message loop (0% CPU). Closing the window ends the process.
#[cfg(target_os = "windows")]
pub fn run_idle(title: &str) {
    use std::ptr::null;
    use windows_sys::Win32::Foundation::{HWND, LPARAM, LRESULT, WPARAM};
    use windows_sys::Win32::Graphics::Gdi::COLOR_WINDOW;
    use windows_sys::Win32::System::LibraryLoader::GetModuleHandleW;
    use windows_sys::Win32::UI::WindowsAndMessaging::*;

    fn wide(s: &str) -> Vec<u16> {
        s.encode_utf16().chain(std::iter::once(0)).collect()
    }

    unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
        if msg == WM_DESTROY {
            PostQuitMessage(0);
            return 0;
        }
        DefWindowProcW(hwnd, msg, wp, lp)
    }

    unsafe {
        let hinst = GetModuleHandleW(null());
        let class = wide("GameSpoofIdleWindow");
        let wc = WNDCLASSW {
            style: 0,
            lpfnWndProc: Some(wndproc),
            cbClsExtra: 0,
            cbWndExtra: 0,
            hInstance: hinst,
            hIcon: 0,
            hCursor: 0,
            hbrBackground: (COLOR_WINDOW + 1) as isize,
            lpszMenuName: null(),
            lpszClassName: class.as_ptr(),
        };
        RegisterClassW(&wc);
        let title_w = wide(&format!("{title} - GameSpoof dummy"));
        CreateWindowExW(
            0,
            class.as_ptr(),
            title_w.as_ptr(),
            WS_OVERLAPPEDWINDOW | WS_VISIBLE,
            CW_USEDEFAULT,
            CW_USEDEFAULT,
            380,
            140,
            0,
            0,
            hinst,
            null(),
        );
        let mut msg: MSG = std::mem::zeroed();
        while GetMessageW(&mut msg, 0, 0, 0) > 0 {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
}

#[cfg(not(target_os = "windows"))]
pub fn run_idle(_title: &str) {
    loop {
        std::thread::sleep(Duration::from_secs(3600));
    }
}

// ------------------------------------------------------------------- helpers

fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

fn local_dir(app: &AppHandle) -> Result<PathBuf, String> {
    let d = app.path().app_local_data_dir().map_err(|e| e.to_string())?;
    fs::create_dir_all(&d).map_err(|e| e.to_string())?;
    Ok(d)
}

fn data_dir(app: &AppHandle) -> Result<PathBuf, String> {
    let d = app.path().app_data_dir().map_err(|e| e.to_string())?;
    fs::create_dir_all(&d).map_err(|e| e.to_string())?;
    Ok(d)
}

fn active_root(app: &AppHandle) -> Result<PathBuf, String> {
    Ok(local_dir(app)?.join("active"))
}

/// Turns a Discord executable name (possibly `Binaries/Win64/Game.exe` or
/// `Game.app/Contents/MacOS/Game`) into a safe relative path, rejecting
/// traversal, drive letters and reserved characters.
fn sanitize_rel_path(raw: &str) -> Result<PathBuf, String> {
    let mut out = PathBuf::new();
    for part in raw.split(|c| c == '/' || c == '\\') {
        let part = part.trim();
        if part.is_empty() || part == "." {
            continue;
        }
        let bad_char = part
            .chars()
            .any(|c| matches!(c, ':' | '<' | '>' | '"' | '|' | '?' | '*') || c.is_control());
        if part == ".." || bad_char || part.ends_with('.') {
            return Err(format!("Unsafe path component: {part}"));
        }
        out.push(part);
    }
    if out.as_os_str().is_empty() {
        return Err("Executable name is empty".into());
    }
    Ok(out)
}

fn safe_id(id: &str) -> Result<String, String> {
    let s: String = id
        .chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '-' || *c == '_')
        .collect();
    if s.is_empty() {
        Err("Invalid application id".into())
    } else {
        Ok(s)
    }
}

/// Deletes the dummy file and prunes any now-empty parent folders up to `root`.
fn remove_target(path: &Path, root: &Path) {
    let _ = fs::remove_file(path);
    let mut cur = path.parent();
    while let Some(dir) = cur {
        if dir == root || !dir.starts_with(root) {
            break;
        }
        if fs::remove_dir(dir).is_err() {
            break;
        }
        cur = dir.parent();
    }
    let _ = fs::remove_dir(root);
}

fn emit_running(app: &AppHandle) {
    let state = app.state::<AppState>();
    let list: Vec<RunningInfo> = lock(&state).values().map(|r| r.info()).collect();
    let _ = app.emit("running-changed", list);
}

fn stop_everything(app: &AppHandle) {
    let state = app.state::<AppState>();
    let drained: Vec<Running> = lock(&state).drain().map(|(_, v)| v).collect();
    for mut r in drained {
        let _ = r.child.kill();
        let _ = r.child.wait();
    }
    if let Ok(root) = active_root(app) {
        let _ = fs::remove_dir_all(root);
    }
    emit_running(app);
}

// ----------------------------------------------------------- process spawner

#[cfg(target_os = "windows")]
fn spawn_stub(target: &Path, title: &str) -> Result<Child, String> {

    // The stub is this very executable run in idle mode: a valid PE file that
    // exits the Tauri code path immediately and sleeps with 0% CPU.
    let me = std::env::current_exe().map_err(|e| e.to_string())?;
    let _ = fs::remove_file(target);
    fs::copy(&me, target).map_err(|e| format!("Could not create dummy executable: {e}"))?;

    Command::new(target)
        .arg(IDLE_FLAG)
        .arg(title)
        .current_dir(target.parent().unwrap_or_else(|| Path::new(".")))
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| format!("Could not launch dummy process: {e}"))
}

// macOS (and Linux, for development builds)
#[cfg(not(target_os = "windows"))]
fn spawn_stub(target: &Path, title: &str) -> Result<Child, String> {
    use std::os::unix::fs::PermissionsExt;

    let dir = target.parent().unwrap_or_else(|| Path::new("."));
    let _ = fs::remove_file(target);
    fs::copy("/bin/sleep", target).map_err(|e| format!("Could not copy /bin/sleep: {e}"))?;
    fs::set_permissions(target, fs::Permissions::from_mode(0o755)).map_err(|e| e.to_string())?;

    // `sleep 86400` idles for 24h at 0% CPU; the monitor drops it afterwards.
    let first = Command::new(target)
        .arg("86400")
        .current_dir(dir)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn();

    match first {
        Ok(child) => Ok(child),
        Err(_) => {
            // Fallback: the copied system binary was refused (e.g. signature
            // policy). Use this app's own binary in idle mode instead.
            let me = std::env::current_exe().map_err(|e| e.to_string())?;
            let _ = fs::remove_file(target);
            fs::copy(&me, target).map_err(|e| e.to_string())?;
            fs::set_permissions(target, fs::Permissions::from_mode(0o755))
                .map_err(|e| e.to_string())?;
            Command::new(target)
                .arg(IDLE_FLAG)
                .arg(title)
                .current_dir(dir)
                .stdin(Stdio::null())
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .spawn()
                .map_err(|e| format!("Could not launch dummy process: {e}"))
        }
    }
}

// ------------------------------------------------------------------ commands

#[tauri::command]
fn get_platform() -> String {
    if cfg!(target_os = "windows") {
        "win32".into()
    } else if cfg!(target_os = "macos") {
        "darwin".into()
    } else {
        "linux".into()
    }
}

fn build_catalog(raw: Vec<serde_json::Value>) -> Catalog {
    let mut games = Vec::new();
    for g in raw {
        let (Some(id), Some(name)) = (
            g.get("id").and_then(|v| v.as_str()),
            g.get("name").and_then(|v| v.as_str()),
        ) else {
            continue;
        };
        let mut execs = Vec::new();
        if let Some(arr) = g.get("executables").and_then(|v| v.as_array()) {
            for e in arr {
                let Some(n) = e.get("name").and_then(|v| v.as_str()) else {
                    continue;
                };
                let n = n.trim_start_matches('>').trim().to_string();
                if n.is_empty() {
                    continue;
                }
                execs.push(ExecEntry {
                    name: n,
                    os: e
                        .get("os")
                        .and_then(|v| v.as_str())
                        .unwrap_or("win32")
                        .to_string(),
                    is_launcher: e.get("is_launcher").and_then(|v| v.as_bool()).unwrap_or(false),
                });
            }
        }
        if execs.is_empty() {
            continue;
        }
        let steam_id = g
            .get("third_party_skus")
            .and_then(|v| v.as_array())
            .and_then(|arr| {
                arr.iter()
                    .find(|sku| sku.get("distributor").and_then(|d| d.as_str()) == Some("steam"))
            })
            .and_then(|sku| sku.get("id").or_else(|| sku.get("sku")))
            .and_then(|v| v.as_str())
            .filter(|v| !v.is_empty() && v.chars().all(|c| c.is_ascii_digit()))
            .map(|v| v.to_string());
        games.push(Game {
            id: id.to_string(),
            name: name.to_string(),
            icon: g
                .get("icon")
                .and_then(|v| v.as_str())
                .filter(|v| !v.is_empty())
                .map(|v| v.to_string()),
            steam_id,
            executables: execs,
        });
    }
    games.sort_by(|a, b| a.name.to_lowercase().cmp(&b.name.to_lowercase()));
    Catalog {
        updated_at: now_ms(),
        games,
    }
}

#[tauri::command]
fn load_catalog(app: AppHandle) -> Result<Option<Catalog>, String> {
    let path = data_dir(&app)?.join("games_cache.json");
    match fs::read_to_string(&path) {
        Ok(s) => Ok(serde_json::from_str::<Catalog>(&s).ok()),
        Err(_) => Ok(None),
    }
}

#[tauri::command]
async fn sync_catalog(app: AppHandle) -> Result<Catalog, String> {
    let client = reqwest::Client::builder()
        .user_agent("GameSpoofStudio/1.0")
        .timeout(Duration::from_secs(60))
        .build()
        .map_err(|e| e.to_string())?;
    let resp = client
        .get(DETECTABLE_URL)
        .send()
        .await
        .map_err(|e| format!("Network error: {e}"))?;
    if !resp.status().is_success() {
        return Err(format!("Discord returned HTTP {}", resp.status()));
    }
    let raw: Vec<serde_json::Value> = resp
        .json()
        .await
        .map_err(|e| format!("Unexpected catalog format: {e}"))?;
    let catalog = build_catalog(raw);
    let bytes = serde_json::to_vec(&catalog).map_err(|e| e.to_string())?;
    fs::write(data_dir(&app)?.join("games_cache.json"), bytes).map_err(|e| e.to_string())?;
    Ok(catalog)
}

/// Looks up app icon hashes straight from Discord for games the catalog has no
/// icon for. Results (including "no icon") are cached in `icons_cache.json`.
#[tauri::command]
async fn resolve_icons(app: AppHandle, ids: Vec<String>) -> Result<HashMap<String, String>, String> {
    let path = data_dir(&app)?.join("icons_cache.json");
    let mut cache: HashMap<String, String> = fs::read_to_string(&path)
        .ok()
        .and_then(|s| serde_json::from_str::<HashMap<String, String>>(&s).ok())
        .unwrap_or_default();

    let wanted: Vec<String> = ids
        .into_iter()
        .filter(|i| !i.is_empty() && i.len() <= 24 && i.chars().all(|c| c.is_ascii_digit()))
        .take(40)
        .collect();
    let todo: Vec<String> = wanted
        .iter()
        .filter(|i| !cache.contains_key(*i))
        .cloned()
        .collect();

    if !todo.is_empty() {
        let client = reqwest::Client::builder()
            .user_agent("GameSpoofStudio/1.0")
            .timeout(Duration::from_secs(15))
            .build()
            .map_err(|e| e.to_string())?;
        for chunk in todo.chunks(8) {
            let mut handles = Vec::new();
            for id in chunk {
                let client = client.clone();
                let id = id.clone();
                handles.push(tauri::async_runtime::spawn(async move {
                    let url = format!("https://discord.com/api/v9/applications/{}/rpc", id);
                    let resp = client.get(&url).send().await.ok()?;
                    let status = resp.status();
                    if status.as_u16() == 404 {
                        return Some((id, None::<String>));
                    }
                    if !status.is_success() {
                        return None; // transient (e.g. rate limit): don't cache
                    }
                    let v: serde_json::Value = resp.json().await.ok()?;
                    let icon = v
                        .get("icon")
                        .and_then(|x| x.as_str())
                        .filter(|x| !x.is_empty() && x.chars().all(|c| c.is_ascii_alphanumeric() || c == '_'))
                        .map(|x| x.to_string());
                    Some((id, icon))
                }));
            }
            for h in handles {
                if let Ok(Some((id, icon))) = h.await {
                    cache.insert(id, icon.unwrap_or_default());
                }
            }
        }
        if let Ok(bytes) = serde_json::to_vec(&cache) {
            let _ = fs::write(&path, bytes);
        }
    }

    let mut out = HashMap::new();
    for id in wanted {
        if let Some(icon) = cache.get(&id) {
            if !icon.is_empty() {
                out.insert(id, icon.clone());
            }
        }
    }
    Ok(out)
}

#[tauri::command]
fn read_store(app: AppHandle, name: String) -> Result<String, String> {
    if !STORE_NAMES.contains(&name.as_str()) {
        return Err("Unknown store".into());
    }
    let p = local_dir(&app)?.join(&name);
    Ok(fs::read_to_string(p).unwrap_or_else(|_| "[]".into()))
}

#[tauri::command]
fn write_store(app: AppHandle, name: String, data: String) -> Result<(), String> {
    if !STORE_NAMES.contains(&name.as_str()) {
        return Err("Unknown store".into());
    }
    serde_json::from_str::<serde_json::Value>(&data).map_err(|e| e.to_string())?;
    fs::write(local_dir(&app)?.join(&name), data).map_err(|e| e.to_string())
}

#[tauri::command]
fn list_running(state: State<AppState>) -> Vec<RunningInfo> {
    lock(&state).values().map(|r| r.info()).collect()
}

#[tauri::command]
fn start_game(
    app: AppHandle,
    state: State<AppState>,
    app_id: String,
    name: String,
    exe: String,
) -> Result<RunningInfo, String> {
    let rel = sanitize_rel_path(&exe)?;
    let id = safe_id(&app_id)?;
    let key = format!("{}::{}", app_id, exe.to_lowercase());

    if let Some(existing) = lock(&state).get(&key) {
        return Ok(existing.info());
    }

    let root = active_root(&app)?;
    let target = root.join(&id).join(&rel);
    if let Some(parent) = target.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }

    let child = match spawn_stub(&target, &name) {
        Ok(c) => c,
        Err(e) => {
            remove_target(&target, &root);
            return Err(e);
        }
    };

    let running = Running {
        key: key.clone(),
        app_id,
        name,
        exe,
        path: target,
        root: root.join(&id),
        pid: child.id(),
        started_at: now_ms(),
        child,
    };
    let info = running.info();
    lock(&state).insert(key, running);
    emit_running(&app);
    Ok(info)
}

#[tauri::command]
fn stop_game(app: AppHandle, state: State<AppState>, key: String) -> Result<(), String> {
    let removed = lock(&state).remove(&key);
    if let Some(mut r) = removed {
        let _ = r.child.kill();
        let _ = r.child.wait();
        remove_target(&r.path, &r.root);
    }
    emit_running(&app);
    Ok(())
}

#[tauri::command]
fn stop_all(app: AppHandle) -> Result<(), String> {
    stop_everything(&app);
    Ok(())
}

// ------------------------------------------------------------------- monitor

/// Every 2 seconds, drop games whose child process has exited.
fn monitor(app: AppHandle) {
    loop {
        std::thread::sleep(Duration::from_secs(2));
        let state = app.state::<AppState>();
        let mut dead = Vec::new();
        {
            let mut map = lock(&state);
            let keys: Vec<String> = map.keys().cloned().collect();
            for k in keys {
                let gone = match map.get_mut(&k) {
                    Some(r) => !matches!(r.child.try_wait(), Ok(None)),
                    None => false,
                };
                if gone {
                    if let Some(r) = map.remove(&k) {
                        dead.push(r);
                    }
                }
            }
        }
        if !dead.is_empty() {
            for r in &dead {
                remove_target(&r.path, &r.root);
            }
            emit_running(&app);
        }
    }
}

// ----------------------------------------------------------------------- run

pub fn run() {
    let app = tauri::Builder::default()
        .manage(AppState::default())
        .setup(|app| {
            let handle = app.handle().clone();
            // Clear leftovers from a previous crash.
            if let Ok(root) = active_root(&handle) {
                let _ = fs::remove_dir_all(root);
            }
            std::thread::spawn(move || monitor(handle));
            Ok(())
        })
        .on_window_event(|window, event| {
            if let tauri::WindowEvent::CloseRequested { .. } = event {
                stop_everything(window.app_handle());
            }
        })
        .invoke_handler(tauri::generate_handler![
            get_platform,
            load_catalog,
            sync_catalog,
            resolve_icons,
            read_store,
            write_store,
            list_running,
            start_game,
            stop_game,
            stop_all
        ])
        .build(tauri::generate_context!())
        .expect("error while building GameSpoof Studio");

    app.run(|handle, event| {
        if let RunEvent::Exit = event {
            stop_everything(handle);
        }
    });
}
