# GameSpoof Studio

Local dummy game launcher (Tauri v2 + React + Tailwind). No Discord login, password or token is ever requested.
It places a zero-CPU idle process at the exact path Discord's detectable-games catalog expects, so the official
Discord client sees a running game.

## Develop
```
npm install
npx tauri icon app-icon.png   # generates src-tauri/icons (once)
npm run tauri dev
```

## Build
Push a `v*` tag or run the "Build GameSpoof Studio" workflow manually (Actions tab).

## How the dummy process works
- Windows: the app copies its own executable to `<local data>/active/<app_id>/<exe path>` and launches it with
  `--gamespoof-idle` (CREATE_NO_WINDOW). `main.rs` sees the flag and just sleeps — no window, 0% CPU.
- macOS: `/bin/sleep` is copied to the exact path and run with `86400`. Falls back to the idle-flag binary if refused.
- All children are polled every 2s, and killed + deleted on Stop or window close.
